package com.lexing.batterytest;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.lexing.batterytest.batteryhelper.BatterySipper;
import com.lexing.batterytest.batteryhelper.BatteryStatsHelper;

import java.util.List;

public class MainActivity extends Activity {
    private final int PROGRESS_DIALOG_ID = 1;

    private TextView batterySummary;
    private ListView listView;
    private customAdapter adapter;
    private BatteryStatsHelper helper;
    private ProgressDialog progressDialog;
    private List<BatterySipper> mList;
    private String mBatterySummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_below_jellybean);

        batterySummary = (TextView) findViewById(R.id.batterySummary);
        listView = (ListView) findViewById(R.id.listview);
        adapter = new customAdapter();
        listView.setAdapter(adapter);

        helper = new BatteryStatsHelper();
        helper.setMinPercentOfTotal(0.01f);

        registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        getBatteryStats();
    }

    private void getBatteryStats() {
        showDialog(PROGRESS_DIALOG_ID);
        new Thread() {
            public void run() {
                mList = helper.getBatteryStats(MainActivity.this);
                for(BatterySipper sipper : mList){
                    Utils.getQuickNameIcon(MainActivity.this, sipper);
                }
                mHandler.sendEmptyMessage(1);
            }
        }.start();
    }

    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    if (isFinishing())
                        return;
                    progressDialog.dismiss();
                    batterySummary.setText(mBatterySummary + "\n测试信息：获取方式(根据CPU使用时间)");
                    adapter.setData(mList);
                    break;
            }
        }
    };

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case PROGRESS_DIALOG_ID:
                progressDialog = new ProgressDialog(this);
                progressDialog.setMessage("请稍候...");
                return progressDialog;
        }
        return null;
    }

    class customAdapter extends BaseAdapter {
        private LayoutInflater inflater;

        public customAdapter() {
            inflater = LayoutInflater.from(MainActivity.this);
        }

        public void setData(List<BatterySipper> sipperList) {

            mList = sipperList;
            for (int i = mList.size() - 1; i >= 0; i--) {
                final BatterySipper sipper = mList.get(i);
                String name = sipper.getName();
                Drawable icon = sipper.getIcon();
                if (name != null) {
                    if (icon == null) {
                        PackageManager pm = getPackageManager();
                        icon = pm.getDefaultActivityIcon();
                        sipper.setIcon(icon);
                    }
                } else {
                    mList.remove(i);
                }
            }
            notifyDataSetInvalidated();
        }

        @Override
        public int getCount() {
            return mList == null ? 0 : mList.size();
        }

        @Override
        public BatterySipper getItem(int position) {
            return mList == null ? null : mList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder holder = null;
            if (convertView == null) {
                holder = new Holder();
                convertView = inflater.inflate(R.layout.listview_item, null);
                holder.appIcon = (ImageView) convertView.findViewById(R.id.appIcon);
                holder.appName = (TextView) convertView.findViewById(R.id.appName);
                holder.txtProgress = (TextView) convertView.findViewById(R.id.txtProgress);
                holder.progress = (ProgressBar) convertView.findViewById(R.id.progress);
                convertView.setTag(holder);
            } else {
                holder = (Holder) convertView.getTag();
            }

            BatterySipper appInfo = getItem(position);
            holder.appName.setText(appInfo.getName());
            holder.appIcon.setImageDrawable(appInfo.getIcon());

            double percentOfTotal = appInfo.getPercentOfTotal();
            holder.txtProgress.setText(format(percentOfTotal));
            holder.progress.setProgress((int) percentOfTotal);

            return convertView;
        }
    }

    class Holder {
        ImageView appIcon;
        TextView appName;
        TextView txtProgress;
        ProgressBar progress;
    }

    private String format(double size) {
        return String.format("%1$.2f%%", size);
        // return new BigDecimal("" + size).setScale(2, BigDecimal.ROUND_HALF_UP).toString();
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(mBatteryInfoReceiver);
        super.onDestroy();
    }

    private BroadcastReceiver mBatteryInfoReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                String batteryLevel = Utils.getBatteryPercentage(intent);
                String batteryStatus = Utils.getBatteryStatus(MainActivity.this.getResources(), intent);
                mBatterySummary = context.getResources().getString(R.string.power_usage_level_and_status, batteryLevel, batteryStatus);
            }
        }
    };
}
